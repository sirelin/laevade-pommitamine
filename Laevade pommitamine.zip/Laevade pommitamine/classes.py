import random

class Laev:
    def __init__(self, suurus):
        self.rida = random.randrange(0,9)
        self.veerg = random.randrange(0,9)
        self.suurus = suurus
        self.suund = random.choice(["h", "v"])
        self.indeksid = self.indeksite_arvutus()
    def indeksite_arvutus(self):
        algus_indeks = self.rida * 10 +self.veerg
        if self.suund == "h":
            return [algus_indeks + i for i in range(self.suurus)]
        elif self.suund == "v":
            return [algus_indeks + i*10 for i in range(self.suurus)]

class Mängija:
    def __init__(self):
        self.laevad = []
        self.otsimine = ["U" for i in range(100)] #"U" esindab Unknown ruutu
        self.laeva_paigutamine(suurused = [5, 4, 3, 3, 2])
        lists = [laev.indeksid for laev in self.laevad]
        self.indeksid = [indeks for ala_list in lists for indeks in ala_list]

    def laeva_paigutamine(self, suurused):
        for suurus in suurused:
            paigutatud = False
            while not paigutatud:
                #uus laev
                laev = Laev(suurus)
                paigutus_võimalik = True
                for i in laev.indeksid:
                    if i >= 100:
                        paigutus_võimalik = False
                        break
                    uus_rida = i // 10
                    uus_veerg = i % 10
                    if uus_rida != laev.rida and uus_veerg != laev.veerg:
                        paigutus_võimalik = False
                        break
                    for teine_laev in self.laevad:
                        if i in teine_laev.indeksid:
                            paigutus_võimalik = False
                            break

                if paigutus_võimalik:
                    self.laevad.append(laev)
                    paigutatud = True


    def näita_laevu(self):
        indeksid = ["-" if i not in self.indeksid else "X" for i in range(100)]
        for rida in range(10):
            print(" ".join(indeksid[(rida-1)*10:rida*10]))

class Game:
    def __init__(self):
        self.mängija = Mängija()
        self.arvuti = Mängija()
        self.mängija_kord = True
        self.läbi = False
        self.tulemus = None
        self.lasud = 50

    def laskmine(self, i):
        mängija = self.mängija if self.mängija_kord else self.arvuti
        vastane = self.arvuti if self.mängija_kord else self.mängija

        # pihtas "P" või mööda "M" või "X" põhjas
        if i in vastane.indeksid:
            mängija.otsimine[i] = "P"
            self.lasud -= 1
            for laev in vastane.laevad:
                põhjas = True
                for i in laev.indeksid:
                    if mängija.otsimine[i] == "U":
                        põhjas = False

                        break
                if põhjas:
                    for i in laev.indeksid:
                        mängija.otsimine[i] = "X"



        else:
            mängija.otsimine[i] = "M"
            self.lasud -= 1


        # mängu lõpp?
        mäng_läbi = True

        for i in vastane.indeksid:
            if mängija.otsimine[i] == "U":
                mäng_läbi = False
        #self.läbi = mäng_läbi

        if self.lasud == 0:
            mäng_läbi = True
            self.läbi = mäng_läbi
            self.tulemus = f"Lasud said otsa :("
        else:
            self.tulemus = f"Palju õnne! Laske jäi järgi: {self.lasud}"
        self.läbi = mäng_läbi

        #self.tulemus = f"Palju õnne! Laske jäi järgi: " if self.mängija_kord else "Lasud said otsa :("

