from classes import Mängija
from classes import Game
import pygame

pygame.init()
pygame.font.init()
pygame.display.set_caption("Laevade pommitamine")
teksti_font = pygame.font.SysFont("freesansttf", 30)
ruut = 45
äärised = ruut *2
laius = 600
pikkus = 600
laeva_ääris = 10

screen = pygame.display.set_mode((laius, pikkus))

# värvid
pink = (255,182,193)
valge = (255, 250, 250)
sinine = (135,206,235)
hall = (211,211,211)
must = (0,0,0)
punane = (220,20,60)
lilla = (147,112,219)

värvid = {"U": hall, "M": sinine, "P": must, "X": lilla}
# ruudustiku joonistamine
def ruudustik(mängija, left = 0, top = 0, otsimine = False):
    for i in range(100):
        x = left + i % 10 * ruut
        y = top + i // 10 * ruut
        ruuduke = pygame.Rect(x, y, ruut, ruut)
        pygame.draw.rect(screen, valge, ruuduke, width = 3)
        if otsimine:
            x += ruut // 2
            y += ruut // 2
            pygame.draw.circle(screen, värvid[mängija.otsimine[i]], (x,y), radius = ruut//4)

def laevade_joonistamine(mängija, left = 0, top = 0):
    for laev in mängija.laevad:
        x = left + laev.veerg * ruut + laeva_ääris
        y = top + laev.rida * ruut + laeva_ääris
        if laev.suund == "h":
            width = laev.suurus * ruut - 2* laeva_ääris
            height = ruut - 2*laeva_ääris
        else:
            width = ruut- 2* laeva_ääris
            height = laev.suurus * ruut - 2* laeva_ääris
        ristkülik = pygame.Rect(x, y, width, height)
        pygame.draw.rect(screen, punane, ristkülik, border_radius = 15)

mängija = Mängija()
mäng = Game()

# main loop
running = True
pausing = False
while running:


    lasked = mäng.lasud



    # kasutaja tegevus
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            x,y = pygame.mouse.get_pos()
            if mäng.mängija_kord:
                rida = y // ruut
                veerg = x // ruut
                indeks = rida * 10 + veerg
                if mäng.läbi == False:
                    mäng.laskmine(indeks)



        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            if event.key == pygame.K_SPACE:
                pausing = not pausing


    if not pausing:
        # taust
        screen.fill(pink)
        ruudustik(mäng.mängija, left = 0, top = 0, otsimine = True)
        lives_label = teksti_font.render(f"Lasud: {lasked}", 1, (255, 255, 255))
        screen.blit(lives_label, ((460), 10))

        #pygame.display.update()



        if mäng.läbi:
            tulemuss = mäng.tulemus1
            if mäng.tulemus == tulemuss:
                laevade_joonistamine(mäng.arvuti, left=0, top=0)
                text = "Mäng läbi! " + str(mäng.tulemus)
                textbox = teksti_font.render(text, 1, lilla)
                screen.blit(textbox, (laius // 2 - 280, pikkus // 2 + 155))
            else:

                text = "Mäng läbi! " + str(mäng.tulemus) + str(mäng.lasud)
                textbox = teksti_font.render(text, 1, lilla)
                screen.blit(textbox, (laius//2 - 280, pikkus//2 + 155))


        pygame.display.flip()
