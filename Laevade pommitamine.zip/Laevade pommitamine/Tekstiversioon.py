# Sirelin ja Karoliina


import random
import time
# "." - vesi
# "L" - laev
# "X" - pihta saanud laeva osa
# "M" - möödas lask vees

ruudustik = [[]]
ruudustiku_suurus = 10
laevade_arv = 8
lasud = 50
mängu_lõpp = False
tabatud_laevad = 0
laeva_asukohad = [[]]
tähed ="ABCDEFGHIJ"

def ruudustiku_kontroll(rea_algus, rea_lõpp, veeru_algus, veeru_lõpp):

    global ruudustik
    global laeva_asukohad

    kõik_sobib = True
    for r in range(rea_algus, rea_lõpp):
        for v in range(veeru_algus, veeru_lõpp):
            if ruudustik[r][v] != ".":
                kõik_sobib = False
                break
    if kõik_sobib:
        laeva_asukohad.append([rea_algus, rea_lõpp, veeru_algus, veeru_lõpp])
        for r in range(rea_algus, rea_lõpp):
            for v in range(veeru_algus, veeru_lõpp):
                ruudustik[r][v] = "L"
    return kõik_sobib


def laeva_paigutamine(rida, veerg, suund, pikkus):

    global ruudustiku_suurus
    rea_algus, rea_lõpp, veeru_algus, veeru_lõpp = rida, rida + 1, veerg, veerg + 1
    if suund == "vasak":
        if veerg - pikkus < 0:
            return False
        veeru_algus = veerg - pikkus + 1

    elif suund == "parem":
        if veerg + pikkus >= ruudustiku_suurus:
            return False
        veeru_lõpp = veerg + pikkus

    elif suund == "üles":
        if rida - pikkus < 0:
            return False
        rea_algus = rida - pikkus + 1


    elif suund == "alla":
        if rida + pikkus >= ruudustiku_suurus:
            return False
        rea_lõpp = rida + pikkus




    return ruudustiku_kontroll(rea_algus, rea_lõpp, veeru_algus, veeru_lõpp)

def loo_ruudustik():

    global ruudustik
    global ruudustiku_suurus
    global laevade_arv
    global laeva_asukohad

    random.seed(time.time())

    read, veerud = (ruudustiku_suurus, ruudustiku_suurus)

    ruudustik = []
    for r in range(read):
        rida = []
        for v in range(veerud):
            rida.append(".")
        ruudustik.append(rida)

    laevad_paigutatud = 0

    laeva_asukohad = []

    while laevad_paigutatud != laevade_arv:
        suvaline_rida = random.randint(0, read-1)
        suvaline_veerg = random.randint(0, veerud -1)
        suund = random.choice(["vasak", "parem", "üles", "alla"])
        laeva_suurus = random.randint(3,5)
        if laeva_paigutamine(suvaline_rida, suvaline_veerg, suund, laeva_suurus):
            laevad_paigutatud += 1


def ruudustiku_print():

    global ruudustik
    global tähed

    debug_mode = False

    for rida in range(len(ruudustik)):
        print(tähed[rida], end=") ")
        for veerg in range(len(ruudustik[rida])):
            if ruudustik[rida][veerg] == "L":
                if debug_mode:
                    print("L", end=" ")
                else:
                    print(".", end=" ")
            else:
                print(ruudustik[rida][veerg], end=" ")
        print("")

    print("  ", end=" ")
    for i in range(len(ruudustik[0])):
        print(str(i), end=" ")
    print("")

def lasu_kontroll():

    global tähed
    global ruudustik

    lubatud_lask = False
    rida = -1
    veerg = -1
    while lubatud_lask is False:
        paigutus = input("Sisesta rida (A-J) ja veerg (0-9), nagu nt. A3: ")
        paigutus = paigutus.upper()
        if len(paigutus) <= 0 or len(paigutus) > 2:
            print("Palun sisesta jälgides vormistust A3")
            continue
        rida = paigutus[0]
        veerg = paigutus[1]
        if not rida.isalpha() or not veerg.isnumeric():
            print("Palun sisesta rida (A-J) ja veerg (0-9), nagu nt. A3")
            continue
        rida = tähed.find(rida)
        if not (-1 < rida < ruudustiku_suurus):
            print("Palun sisesta rida (A-J) ja veerg (0-9), nagu nt. A3")
            continue
        veerg = int(veerg)
        if not (-1 < veerg < ruudustiku_suurus):
            print("Palun sisesta rida (A-J) ja veerg (0-9), nagu nt. A3")
            continue
        if ruudustik[rida][veerg] == "M" or ruudustik[rida][veerg] == "X":
            print("Oled siia juba tulistanud, vali midagi muud")
            continue
        if ruudustik[rida][veerg] == "." or ruudustik[rida][veerg] == "L":
            lubatud_lask = True

    return rida, veerg


def kontrolli_lastud_laevu(rida, veerg):

    global laeva_asukohad
    global ruudustik

    for asukoht in laeva_asukohad:
        rea_algus = asukoht[0]
        rea_lõpp = asukoht[1]
        veeru_algus = asukoht[2]
        veeru_lõpp = asukoht[3]
        if rea_algus <= rida <= rea_lõpp and veeru_algus <= veerg <= veeru_lõpp:
            for r in range(rea_algus, rea_lõpp):
                for v in range(veeru_algus, veeru_lõpp):
                    if ruudustik[r][v] != "X":
                        return False
    return True

def laskmine():

    global ruudustik
    global tabatud_laevad
    global lasud

    rida, veerg = lasu_kontroll()
    print("")
    print("------------------------")

    if ruudustik[rida][veerg] == ".":
        print("Lasid mööda, ei saanud pihta")
        ruudustik[rida][veerg] = "M"
    elif ruudustik[rida][veerg] == "L":
        print("Said pihta!", end=" ")
        ruudustik[rida][veerg] = "X"
        if kontrolli_lastud_laevu(rida, veerg):
            print("Laev on põhjas!")
            tabatud_laevad += 1
        else:
            print("Laev sai pihta")

    lasud -= 1


def kas_mängu_lõpp():

    global tabatud_laevad
    global laevade_arv
    global lasud
    global mängu_lõpp

    if laevade_arv == tabatud_laevad:
        print("Palju õnne, võitsid!")
        mängu_lõpp = True
    elif lasud <= 0:
        print("Lasud said otsa, mäng läbi!")
        mängu_lõpp = True

def main():

    global mängu_lõpp

    print("-----Laevade pommitamine-----")
    print("Sul on 50 lasku 6 laeva hävitamiseks.")

    loo_ruudustik()

    while mängu_lõpp is False:
        ruudustiku_print()
        print("Laevade järelejäänud arv: " + str(laevade_arv - tabatud_laevad))
        print("Laske alles: " + str(lasud))
        laskmine()
        print("------------------------")
        print("")
        kas_mängu_lõpp()


if __name__ == '__main__':
    main()